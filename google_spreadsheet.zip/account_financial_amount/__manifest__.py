{
    "name": "Accounting Financial Amounts",
    "version": "11.0.1.0.0",
    "author": "ADHOC SA",
    "license": "AGPL-3",
    "category": "Accounting",
    "depends": [
        "account",
    ],
    "data": [
    ],
    "demo": [
    ],
    'images': [
    ],
    'installable': True,
}
