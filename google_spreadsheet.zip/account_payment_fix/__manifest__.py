{
    'author': 'ADHOC SA',
    'website': 'www.adhoc.com.ar',
    'license': 'AGPL-3',
    'category': 'Accounting & Finance',
    'data': [
        'views/account_payment_view.xml',
    ],
    'demo': [],
    'depends': [
        'account',
    ],
    'installable': True,
    'name': 'Account Payment Fix',
    'test': [],
    'version': '11.0.1.1.0',
}
