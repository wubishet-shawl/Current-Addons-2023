# -*- coding: utf-8 -*-

from . import partner
from . import account
from . import account_payment
from . import account_invoice
from . import account_bank_statement
from . import account_move
from . import chart_template
from . import account_analytic_line
from . import account_journal_dashboard
from . import product
from . import company
from . import res_config_settings
from . import web_planner
from . import account_cash_rounding
from . import payment_request

