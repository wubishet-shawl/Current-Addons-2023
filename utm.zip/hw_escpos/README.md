The escpos directory contains the MIT licensed pyxmlescpos lib taken from

https://github.com/fvdsn/py-xml-escpos

