# -*- coding: utf-8 -*
from . import im_livechat_channel
from . import ir_autovacuum
from . import mail_channel
from . import rating
