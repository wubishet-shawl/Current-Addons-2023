# -*- coding: utf-8 -*-

from . import test_hr_attendance_constraints
from . import test_hr_attendance_process
