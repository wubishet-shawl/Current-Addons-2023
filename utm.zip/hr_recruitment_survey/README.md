Integrated Surveys
-------------------

Create your own interview canvas based on our best practices. Use the survey
designer to adapt questions to your own process. Ask the applicant to fill in
the survey online, or the interviewer to use it during real interviews.
