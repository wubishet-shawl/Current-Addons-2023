# -*- coding: utf-8 -*-

from . import hr_job
from . import hr_applicant
