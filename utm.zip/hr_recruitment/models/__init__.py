from . import hr_department
from . import hr_recruitment
from . import hr_employee
from . import hr_job
from . import res_config_settings
from . import calendar
