**Create a Petty Cash Account**

#. Go to Invoicing > Configuration > Chart of accounts
#. Create a new petty cash account
#. Type = Bank and Cash or Account type that is asset

Note:

* You will need the "Show Full Accounting Features" to see accounting data
