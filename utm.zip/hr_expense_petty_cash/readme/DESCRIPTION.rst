This module work about expense that paid by petty cash.

General Process:

#. Create Petty Cash Holder
#. Transfer cash to Petty Cash Holder By Vendor bill
#. You can create expense paid by petty cash and select petty cash holder.
#. Then balance of petty cash holder less than amount of expense, you must transfer cash to petty cash holder before Submit Report to Manager.
