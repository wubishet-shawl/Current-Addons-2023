# -*- coding: utf-8 -*-

from . import account_move_line
from . import hr_department
from . import hr_expense
from . import product_template
from . import res_config_settings
from . import web_planner
