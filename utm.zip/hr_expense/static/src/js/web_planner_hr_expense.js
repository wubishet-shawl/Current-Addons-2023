odoo.define('planner_hr_expense.planner', function (require) {
"use strict";

var planner = require('web.planner.common');

});
