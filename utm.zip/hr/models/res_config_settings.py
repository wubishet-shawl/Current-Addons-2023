# -*- coding: utf-8 -*-

from odoo import fields, models
from odoo import api, models
from ast import literal_eval
class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    resource_calendar_id = fields.Many2one(
        'resource.calendar', 'Company Working Hours',
        related='company_id.resource_calendar_id')
    module_hr_org_chart = fields.Boolean(string="Show Organizational Chart")

    account_recievable_account_id = fields.Many2one(
        'account.account', 'Receivable Account', company_dependent=True,
        domain=[('deprecated', '=', False)],
        help="This account will hold the current value of employee receivable.")
    # account_payable_account_id = fields.Many2one(
    #     'account.account', 'Payable Account', company_dependent=True,
    #     domain=[('deprecated', '=', False)],
    #     help="This account will hold the current value of employee payable.")
    @api.model
    def set_values(self):
        super(ResConfigSettings, self).set_values()
        ICPSudo = self.env['ir.config_parameter'].sudo()
        ICPSudo.set_param('hr.account_recievable_account_id', self.account_recievable_account_id.id)
        # ICPSudo.set_param('hr.account_payable_account_id', self.account_payable_account_id.id)

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        get_param = self.env['ir.config_parameter'].sudo().get_param
        res.update(
            # account_payable_account_id=literal_eval(get_param('hr.account_payable_account_id', default='False')),
            account_recievable_account_id=literal_eval(get_param('hr.account_recievable_account_id', default='False')),
        )
        return res

