# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr
from . import res_config_settings
from . import mail_alias
from . import res_partner
from . import res_users
