11.0.1.1.0 (2018-12-13)
~~~~~~~~~~~~~~~~~~~~~~~

* Add the ability to allow negative stock for individual stock locations.
