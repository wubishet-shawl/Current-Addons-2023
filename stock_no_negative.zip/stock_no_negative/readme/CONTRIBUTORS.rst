* Alexis de Lattre <alexis.delattre@akretion.com>
* Eficent Business and IT Consulting Services S.L. <contact@eficent.com>
  * Jordi Ballester
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Tecnativa <https://www.tecnativa.com>
  * Pedro M. Baeza
